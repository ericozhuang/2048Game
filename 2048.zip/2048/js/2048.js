if(!Function.prototype.bind){//解决IE8，bind方法兼容性问题
	Function.prototype.bind = function(obj){
		var fun = this;
		var args = Array.prototype.slice.call(arguments,1);
		return function(){
			fun.apply(obj,args.concat(Array.prototype.slice.call(arguments)));
		}
	}
}
function $(id){
	return document.getElementById(id);
}
var game={
	data:[],//保存4X4个单元格中数据的二维数组
	RN:4,//总行数
	CN:4,//纵列数
	score:0,
	top:0,//最高分
	state:1,//游戏状态：进行中：1 结束：0
	RUNNING:1,//运行状态
	GAMEOVER:0,//结束状态
	PLAYING:2,//动画播放中的状态
	init:function(){//初始化所有格子div的html代码
		var gridPanel = $("gridPanel");
		//设置id为gridPanel的宽为：CN*116+16+"px"；
		gridPanel.style.width = this.CN*116+16+"px";
		//设置id为gridPanel的高为：RN*116+16+"px"；
		gridPanel.style.height = this.RN*116+16+"px";
		var grids = [];
		var cells = [];
		//r从0开始，到<RN结束，每次++
		for(var r=0;r<this.RN;r++){
		//	c从0开始，到<CN结束，每次++
			for(var c=0;c<this.CN;c++){
		//	在grids中push一个字符串：	
		//		‘<div id="g'+r+c+'" class="grid"></div>’
				grids.push('<div id="g'+r+c+'" class="grid"></div>');
		//	在cells中push一个字符串
		//		‘<div id="c'+r+c+'" class="cell"></div>’
				cells.push('<div id="c'+r+c+'" class="cell"></div>');
			}
		}//（遍历结束）
		//找到id为gridPanel的div，设置内容为：
		//	grids无缝拼接的结果+cell无缝拼接的结果
		gridPanel.innerHTML = grids.join("")+cells.join("");
	},

	start:function(){//开始游戏方法
		this.init();//生成游戏界面
		animation.init();
		//留住this
		//var self = this;
		//将data初始化为RNxCN的二维数组，每个元素初始化为0
		//r从0结束，到<RN结束，遍历每一行
		for(var r=0;r<this.RN;r++){
		//  在data中压入一个空数组
			this.data.push([]);
		//  c从0开始，到<CN结束，遍历行中每个格
			for(var c=0;c<this.CN;c++){
		//		将data中当前位置设置为0
				this.data[r][c] = 0;
			}
		}
		this.score = 0;//初始化分数为0
		$("top").innerHTML = this.getTop();
		this.state = this.RUNNING;//初始化游戏状态为运行
		$("gameOver").style.display = "none";
		this.randomNum();//生成一个随机数
		this.randomNum();//再生成一个随机数
		this.updateView();//更新页面元素
		//绑定键盘事件
		document.onkeydown=function(){
			if(this.state == this.RUNNING){
				//获得事件对象
				var e = window.event||arguments[0];
				//alert(e.keyCode);//打桩
				switch(e.keyCode){//判断按键号
					case 37:this.moveLeft();break;
					case 39:this.moveRight();break;
					case 38:this.moveUp();break;
					case 40:this.moveDown();break;
				}
			}
		}.bind(this);
	},
	setTop:function(value){
		var now = new Date();
		now.setFullYear(now.getFullyear()+1);
		document.cookie = "top="+value+";expires="+now.toGMTSring();
	},
	getTop:function(){
		var top = parseInt(document.cookie.slice(4));
		return isNaN(top)?0:top;	
	},
	updateView:function(){//将生成数更新在页面
		//遍历data中么个元素
		for(var r=0;r<this.RN;r++){
			for(var c=0;c<this.CN;c++){
				//	拼id:“c”+r+c
				//	使用$找到指定id的格子div对象，保存在变量div中
				var div = $("c"+r+c);
				//  如果当前元素的值为0，（清空div的样式和内容）
				if(this.data[r][c]==0){
					//		将div的内容设置为“”
					div.innerHTML = "";
					//		设置div的class属性为“cell”
					div.className = "cell";
				}else{//	否则
					//		将div的内容设置为当前元素的值
					div.innerHTML = this.data[r][c];
					//		设置div的class属性为“cell n”+data[r][c]当前元素值
					div.className = "cell n"+this.data[r][c];
				}
			}
		}
		//找到id为score的span，直接修改器内容为游戏的score属性
		$("score").innerHTML = this.score;
		//调用isGameOver方法，如果返回true
		if(this.isGameOver()){
		//	修改游戏状态为GAMROVER
			this.state = this.GAMEOVER;
		//	找到id为finalScore的span，设置内容为游戏的分数
			$("finalScore").innerHTML = this.score;
		//	找到id为GameOver的div，显示出来
			$("gameOver").style.display = "block";
			if(this.score>this.getTop()){
				this.setTop(this.score);
			}
		}
	},
	isGameOver:function(){
		//遍历data中每个元素
		for(var r=0;r<this.RN;r++){
			for(var c=0;c<this.CN;c++){
		//		如果当前元素等于0
				if(this.data[r][c] == 0){
		//			返回false
					return false;
		//		否则，如果c不是最右侧列且当前元素等于右侧元素
				}else if(c!=this.CN-1&&this.data[r][c]==this.data[r][c+1]){
		//			返回false
					return false
		//		否则，如果r不是最下方行且当前元素等于下方元素
				}else if(r!=this.RN-1&&this.data[r][c]==this.data[r+1][c]){
		//			返回false
					return false;
				}
			}
		}//（遍历结束）
		//返回true
		return true;
	},
	randomNum:function(){//生成1个随机数的方法
		for(;;){//死循环
			//在0~RN-1之间生成一个随机行号，保存在变量r中
			var r = Math.floor(Math.random()*this.RN);
			//在0~CN-1之间生成一个随机列号，保存在变量c中
			var c = Math.floor(Math.random()*this.CN);
			//如果data中r行c列的元素==0
			if(this.data[r][c]==0){
				//	再生成一个随机数，
				//  如果<0.5，就在r行c列放入2		
				//		       否则放入
				this.data[r][c]=Math.random()<0.5?2:4;
                //退出循环
				break;
			}
		}
	},
	move:function(iterator){//iterator专门执行for的函数
		var before = this.data.toString();
		iterator.call(this);
		var after = this.data.toString();
		if(before!=after){
			//修改游戏状态为播放动画状态
			//播放动画状态下，不响应键盘事件
			this.state = this.PLAYING;
			//启动动画，传入回调函数
			//回调函数在动画播放完成后，自动执行
			//动画完成后，生成随机数，更新页面，修改动画状态为运行状态，才可继续响应按键事件
			//回调函数要提前绑定this为game对象
			animation.start(function(){
				this.randomNum();
				this.updateView();
				this.state = this.RUNNING;
			}.bind(this));
			
		}
	},
	moveLeft:function(){//遍历每一行，针对每一行执行左移
		/*var before = this.data.toString();
		//遍历data中每一行
		for(var r=0;r<this.RN;r++){
		//	每遍历一行就调用一次moveLeftInRow,传入r
			this.moveLeftInRow(r);
		}//(遍历结束)
		var after = this.data.toString();
		//如果本次发生了移动，才
		if(before!=after){
		//	生成一个随机数
			this.randomNum();
		//	更新界面
			this.updateView();
		}*/
		this.move(function(){
			for(var r=0;r<this.RN;r++){
				this.moveLeftInRow(r);
			}
		});
	},
	moveLeftInRow:function(r){//仅移动指定一行
		//从0位置开始，到<CN-1结束，遍历r行中每个元素
		for(var c=0;c<this.CN-1;c++){
		//	 查找当前位置右侧下一个部位0的位置,保存在nextc中
			var nextc = this.getRightInRow(r,c);
		//  如果没找到,退出循环
			if(nextc == -1){break;}
			else if(this.data[r][c] == 0){//  否则 如果当前元素是0	
		//		将nextc位置的值换到当前位置
				this.data[r][c] = this.data[r][nextc];
		//		将nextc位置设置为0
				this.data[r][nextc] = 0;
				animation.addTask($("c"+r+nextc),r,nextc,r,c);
		//		c留在原地（抵消循环中的变化）
				c--;
			}else if(this.data[r][c] == this.data[r][nextc]){//		否则 如果当前元素==nextc位置的元素
		//		将当前位置*=2
				this.data[r][c] *= 2;
		//		将nextc位置设置为0
				this.data[r][nextc] = 0;
		//		将合并后当前元素的值，计入总分
				this.score += this.data[r][c];
				animation.addTask($("c"+r+nextc),r,nextc,r,c);
			}
		}
	},
	getRightInRow:function(r,c){//查找指定位置右侧下一个不为0的位置下标
		//nextc从c+1开始，遍历r行剩余元素
		for(var nextc=c+1;nextc<this.CN;nextc++){
		//	如果当前位置!=0
			if(this.data[r][nextc]!=0){
		//		返回nextc
				return nextc;
			}
		}//(遍历结束)
		//返回-1
		return -1;
	},
	moveRight:function(){
		this.move(function(){
			for(var r=0;r<this.RN;r++){
				this.moveRightInRow(r);
			}
		});
	},
	moveRightInRow:function(r){
		for(var c=this.CN-1;c>0;c--){
			var prevc = this.getLeftInRow(r,c);
			if(prevc == -1){break;}
			else if(this.data[r][c] == 0){
				this.data[r][c] = this.data[r][prevc];
				this.data[r][prevc] = 0;
				animation.addTask($("c"+r+prevc),r,prevc,r,c);
				c++;
			}else if(this.data[r][c] == this.data[r][prevc]){
				this.data[r][c] *= 2;
				this.data[r][prevc] = 0;
				this.score += this.data[r][c];
				animation.addTask($("c"+r+prevc),r,prevc,r,c);
			}
		}
	},
	getLeftInRow:function(r,c){
		for(var prevc=c-1;prevc>=0;prevc--){
			if(this.data[r][prevc]!=0){
				return prevc;
			}
		}
		return -1;
	},
	moveUp:function(){
		this.move(function(){
			for(var c=0;c<this.CN;c++){
				this.moveUpInCol(c);
			}
		});
	},
	moveUpInCol:function(c){
		for(var r=0;r<this.RN-1;r++){
			var nextr=this.getDownInCol(r,c);
			if(nextr == -1){break;}
			else if(this.data[r][c] == 0){
				this.data[r][c] = this.data[nextr][c];
				this.data[nextr][c] = 0;
				animation.addTask($("c"+nextr+c),nextr,c,r,c);
				r--;
			}else if(this.data[r][c] == this.data[nextr][c]){
				this.data[r][c] *= 2;
				this.data[nextr][c]=0;
				this.score += this.data[r][c];
				animation.addTask($("c"+nextr+c),nextr,c,r,c);
			}
		}
	},
	getDownInCol:function(r,c){
		for(var nextr=r+1;nextr<this.RN;nextr++){
			if(this.data[nextr][c]!=0){
				return nextr;
			}
		}
		return -1;
	},
	moveDown:function(){
		this.move(function(){
			for(var c=0;c<this.CN;c++){
				this.moveDownInCol(c);
			}
		});
	},
	moveDownInCol:function(c){
		for(var r=this.RN-1;r>0;r--){
			var prevr=this.getUpInCol(r,c);
			if(prevr == -1){break;}
			else if(this.data[r][c] == 0){
				this.data[r][c] = this.data[prevr][c];
				this.data[prevr][c] = 0;
				animation.addTask($("c"+prevr+c),prevr,c,r,c);
				r++;
			}else if(this.data[r][c] == this.data[prevr][c]){
				this.data[r][c] *= 2;
				this.data[prevr][c]=0;
				this.score += this.data[r][c];
				animation.addTask($("c"+prevr+c),prevr,c,r,c);
			}
		}
	},
	getUpInCol:function(r,c){
		for(var prevr=r-1;prevr>=0;prevr--){
			if(this.data[prevr][c]!=0){
				return prevr;
			}
		}
		return -1;
	}
}
//页面加载后：页面加载后自动触发！
window.onload=function(){
	game.start();
}
