var animation={
	WIDTH:116,//宽度+margin
	HEIGHT:116,//高度+margin
	duration:100,//总时长
	STEPS:10,//固定总步数
	steps:10,//步数计数器
	interval:0,//每步时间间隔
	timer:null,//保存定时器编号
	tasks:[],//保存所有需要移动的div对象和移动的step
	init:function(){//初始化动画，计算interval
		this.interval = this.duration/this.steps;
	},
	//添加移动任务方法
	//根据div的当前位置和目标位置行列号，计算行列两个方向上每步位移
	addTask:function(div,rFrom,cFrom,rTo,cTo){//向tasks中添加对象
		var rstep = (rTo-rFrom)*this.HEIGHT/this.steps;
		var cstep = (cTo-cFrom)*this.WIDTH/this.steps;
		this.tasks.push({div:div,rstep:rstep,cstep:cstep});//将任务加入任务列表
	},
	//将任务中，每个对象移动一步的方法
	moveStep:function(callback){//移动一步
		for(var i=0;i<this.tasks.length;i++){
			var obj = this.tasks[i];
			var style = getComputedStyle(obj.div);
			obj.div.style.top = parseFloat(style.top)+obj.rstep+"px";
			obj.div.style.left = parseFloat(style.left)+obj.cstep+"px";
		}
		this.steps--;
		if(this.steps == 0){
			clearInterval(this.timer);
			for(var i=0;i<this.tasks.length;i++){
				var obj = this.tasks[i];
				obj.div.style.top = "";
				obj.div.style.left = "";
			}
			this.steps = this.STEPS;
			this.tasks = [];
			//动画结束后，才能继续生成随机数和更新界面
			callback();
		}
	},
	start:function(callback){
		//启动动画方法，将moveStep方法放入定时器，提前绑定this为animation对象，同事绑定动画执行后要自动调用的函数对象
		this.timer = setInterval(this.moveStep.bind(this,callback),this.interval);
	}
}